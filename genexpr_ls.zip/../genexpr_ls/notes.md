### Implementing a language server for genExpr in Typescript

Initialise Node.js project and install typescript compiler and types definitions
for Node.js environment

```bash
npm init
npm install --save-dev typescript @types/node
```

Compile program

```bash
npm run compile
```
