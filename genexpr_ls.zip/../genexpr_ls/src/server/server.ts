import {
  createConnection,
  ProposedFeatures,
  TextDocuments,
  TextDocumentSyncKind,
  MessageType,
  //SemanticTokensBuilder
} from "vscode-languageserver/node";
import { TextDocument } from "vscode-languageserver-textdocument";

import { getSemanticTokens, TokenModifiers, TokenTypes } from "../gen/library";
import logger from "../utils/logger";

//////////////////////////////////////////////////////////////

logger.start();

const connection = createConnection(ProposedFeatures.all);
const documents = new TextDocuments(TextDocument);

documents.onDidOpen((event) => {
  logger.info("Genexpr buffer : " + event.document.uri);

  connection.sendNotification('window/showMessage', {
    type: MessageType.Info,
    message: "Lets GENerate sounds and stuff"
  });
});

documents.listen(connection);

connection.onInitialize(() => {
  return {
    capabilities: {
      textDocumentSync: {
        openClose: true,
        change: TextDocumentSyncKind.Incremental
      },
      semanticTokensProvider: {
        documentSelector: null,
        legend: {
          tokenTypes: TokenTypes,
          tokenModifiers: TokenModifiers,
        },
        full: true,
        range: false,
      }
    }
  }
});

connection.languages.semanticTokens.on((params) => {
  const document = documents.get(params.textDocument.uri);
  if (!document) {
    return { data: [] };
  }

  const data = getSemanticTokens(document);
  return { data };
})

connection.listen();
