import { SemanticTokensBuilder } from "vscode-languageserver";
import { TextDocument } from "vscode-languageserver-textdocument";
import logger from "../utils/logger";


export enum TokenType {
  KEYWORD,
  OPERATOR,
  NUMBER
}
export enum TokenModifier {
  DEFAULT_LIBRARY,
  STATIC
}

export const TokenTypes = [
  'keyword',
  'operator',
  'number'
]
export const TokenModifiers = [
  'defaultLibrary',
  'static'
]

export interface Token {
  regexp: RegExp,
  type: TokenType,
  modifier: TokenModifier
}

export const Tokens: Token[] = [
  { // Inlets & outlets
    regexp: /\b(in\d*|out\d*)\b/g,
    type: TokenType.KEYWORD,
    modifier: TokenModifier.DEFAULT_LIBRARY
  },
  { // Reserved keywords
    regexp: /\b(History|Param)\b/g,
    type: TokenType.KEYWORD,
    modifier: TokenModifier.DEFAULT_LIBRARY
  },
  { // branching & looping
    regexp: /\b(if|else|for|while|break|continue)\b/g,
    type: TokenType.KEYWORD,
    modifier: TokenModifier.DEFAULT_LIBRARY
  },
  { // Functions
    regexp: /\b(return)\b/g,
    type: TokenType.KEYWORD,
    modifier: TokenModifier.DEFAULT_LIBRARY
  },
  { // Punctuation
    regexp: /[;,(){}\[\]=+\-/*|&!<>]/g,
    type: TokenType.OPERATOR,
    modifier: TokenModifier.DEFAULT_LIBRARY
  },
  {
    regexp: /(?<!\w)(-?(?:\d+(?:\.\d+)?|\.\d+))/g,
    type: TokenType.NUMBER,
    modifier: TokenModifier.STATIC
  }
]

function processLine( line: string, lineNumber: number, builder: SemanticTokensBuilder): void {
  for (const token of Tokens) {
    processPattern(line, lineNumber, builder, token);
  }
}

function processPattern(line: string, lineNumber: number, builder: SemanticTokensBuilder, token: Token): void {
  token.regexp.lastIndex = 0;

  let match;
  while ((match = token.regexp.exec(line)) !== null) {
    const startChar = match.index;
    const length = match[0].length;
    //logger.info(`Found token ${match[0]} at position ${startChar} and length ${length}`);

    builder.push(
      lineNumber,
      startChar,
      length,
      token.type,
      1 << token.modifier
    )
  }
}

export function getSemanticTokens(document: TextDocument): number[] {
  const builder = new SemanticTokensBuilder();
  const text = document.getText();
  const lines = text.split("\n");

  for (let lineNumber = 0; lineNumber < lines.length; lineNumber++) {
    const line = lines[lineNumber];
    processLine(line, lineNumber, builder);
  }
  return builder.build().data;
}

